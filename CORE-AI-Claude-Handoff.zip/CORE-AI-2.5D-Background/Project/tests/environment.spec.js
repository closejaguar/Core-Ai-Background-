import { test, expect } from '@playwright/test';
const diagnosticTexture = '<svg xmlns="http://www.w3.org/2000/svg" width="1752" height="898"><defs><pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse"><path d="M0 0H32V32H0Z" fill="#223344"/><path d="M0 0H16V16H0ZM16 16H32V32H16Z" fill="#99aabb"/></pattern></defs><path d="M0 0H1752V898H0Z" fill="url(#grid)"/></svg>';

test('missing asset reports a blocker and disables controls', async ({ page }) => {
  await page.route('**/assets/core-ai-reference.jpg',route=>route.fulfill({status:404,body:''}));
  await page.goto('/');
  await expect(page.locator('#status')).toContainText('could not load');
  await expect(page.locator('#motion')).toBeDisabled();
});
for (const viewport of [{width:1440,height:900},{width:390,height:844}]) {
  test(`scene compiles, renders, compares and disposes at ${viewport.width}px`, async ({page}) => {
    // Diagnostic grid validates the renderer only. It is never a product asset.
    await page.setViewportSize(viewport);
    await page.route('**/assets/core-ai-reference.jpg',route=>route.fulfill({contentType:'image/svg+xml',body:diagnosticTexture}));
    const errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    page.on('console',msg=>{ if(msg.type()==='error') errors.push(msg.text()); });
    await page.goto('/');
    await expect(page.locator('#status')).toBeHidden();
    await expect.poll(()=>page.evaluate(()=>window.chamber.getMetrics().calls)).toBeGreaterThan(1);
    const before=await page.evaluate(()=>window.chamber.getMetrics());
    expect(before.triangles).toBeGreaterThan(100);
    await page.locator('#reference').click();
    await expect.poll(()=>page.evaluate(()=>window.chamber.getMetrics().calls)).toBe(1);
    await page.locator('#reference').click();
    await expect.poll(()=>page.evaluate(()=>window.chamber.getMetrics().calls)).toBeGreaterThan(1);
    await page.locator('#motion').click();
    await expect(page.locator('#motion')).toHaveAttribute('aria-pressed','false');
    const size=await page.locator('canvas').boundingBox();
    expect(size.width/size.height).toBeCloseTo(1752/898,1);
    expect(errors).toEqual([]);
    await page.evaluate(()=>window.chamber.dispose());
    await expect(page.locator('canvas')).toHaveCount(0);
  });
}
test('reduced motion starts with movement disabled',async ({page})=>{
  await page.emulateMedia({reducedMotion:'reduce'});
  await page.route('**/assets/core-ai-reference.jpg',route=>route.fulfill({contentType:'image/svg+xml',body:diagnosticTexture}));
  await page.goto('/');
  await expect(page.locator('#motion')).toHaveAttribute('aria-pressed','false');
});

// Real-asset checks compare the photographed baseline with each geometry stage.
// These catch color-management changes, duplicate glow and projection misalignment.
for (const width of [1440,390]) {
  test(`approved reference remains aligned through depth stages at ${width}px`, async ({page})=>{
    const { PNG }=await import('pngjs');
    await page.setViewportSize({width,height:900});
    await page.emulateMedia({reducedMotion:'reduce'});
    const errors=[];
    page.on('console',message=>{if(message.type()==='error') errors.push(message.text());});
    await page.goto('/');
    await expect(page.locator('#status')).toBeHidden();
    const canvas=page.locator('canvas');
    async function capture(stage) {
      await page.evaluate(stage=>window.chamber.setStage(stage),stage);
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      return PNG.sync.read(await canvas.screenshot());
    }
    const baseline=await capture('reference');
    for(const stage of ['platform','ceiling','architecture']) {
      const actual=await capture(stage);
      expect(actual.width).toBe(baseline.width);expect(actual.height).toBe(baseline.height);
      let error=0,large=0;
      for(let i=0;i<actual.data.length;i+=4) {
        let difference=0;
        for(let c=0;c<3;c++) difference+=Math.abs(actual.data[i+c]-baseline.data[i+c]);
        error+=difference; if(difference>60) large++;
      }
      const pixels=actual.width*actual.height;
      expect(error/(pixels*3),`${stage} mean RGB error`).toBeLessThan(0.5);
      expect(large/pixels,`${stage} obvious changed pixels`).toBeLessThan(0.002);
    }
    // Exercise the maximum permitted movement and ensure reference mode restores
    // the exact static frame, rather than leaving a displaced background.
    await page.evaluate(()=>window.chamber.setMotion(true));
    const bounds=await canvas.boundingBox();
    await page.mouse.move(bounds.x+bounds.width-1,bounds.y+1);
    await expect.poll(()=>page.evaluate(()=>window.chamber.getViewState().x)).toBeGreaterThan(0.01);
    const position=await page.evaluate(()=>window.chamber.getViewState());
    expect(Math.abs(position.x)).toBeLessThanOrEqual(0.022);
    expect(Math.abs(position.y)).toBeLessThanOrEqual(0.022);
    await page.mouse.move(0,0);
    const reset=await capture('reference');
    expect(Buffer.compare(reset.data,baseline.data)).toBe(0);
    expect(errors).toEqual([]);
  });
}
