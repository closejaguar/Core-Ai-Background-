import './style.css';
import { mountEnvironment } from './scene/environment.js';
const element = document.querySelector('#chamber');
const status = document.querySelector('#status');
const motion = document.querySelector('#motion');
const reference = document.querySelector('#reference');
motion.disabled = reference.disabled = true;
let environment;
function fail(message) { status.hidden=false; status.textContent=message; motion.disabled=reference.disabled=true; }
element.addEventListener('environmenterror',event=>fail(event.detail));
try {
  environment = await mountEnvironment(element);
  status.hidden = true;
  motion.disabled = reference.disabled = false;
  function updateMotion() { motion.setAttribute('aria-pressed',String(environment.motionEnabled)); motion.textContent=environment.motionEnabled?'Motion on':'Motion off'; }
  updateMotion();
  motion.addEventListener('click',()=>{ environment.setMotion(!environment.motionEnabled); updateMotion(); });
  reference.addEventListener('click',()=>{
    const value=reference.getAttribute('aria-pressed')!=='true';
    environment.setReference(value);
    reference.setAttribute('aria-pressed',String(value));
    reference.textContent=value?'Return to depth view':'Compare reference';
  });
  if (import.meta.env.DEV) window.chamber=environment;
} catch (error) {
  console.error('Chamber could not start:',error);
  fail('The chamber could not load. Check that the approved reference asset is installed and WebGL is available.');
}
if (import.meta.hot) import.meta.hot.dispose(()=>environment?.dispose());
