import * as THREE from 'three';
import { fromPixel, WIDTH, REFERENCE } from './config.js';
import { projectedMaterial } from './materials.js';

function panel(texture,x1,y1,x2,y2,z) {
  const mesh=new THREE.Mesh(new THREE.BoxGeometry((x2-x1)/REFERENCE.width*WIDTH,(y2-y1)/REFERENCE.width*WIDTH,0.02),projectedMaterial(texture));
  mesh.position.set(...fromPixel((x1+x2)/2,(y1+y2)/2,z));
  return mesh;
}
export function createArchitecture(texture,segments) {
  const group=new THREE.Group();
  group.name='Reference-aligned architectural layers';
  const columns=new THREE.Group(); columns.name='Window structure';
  for(const [x1,y1,x2,y2,z] of [
    [638,170,663,524,0.8],[1067,172,1093,524,0.8],
    [477,136,496,530,0.6],[1250,130,1273,531,0.6],
    [153,82,188,482,1.0],[1561,79,1594,482,1.0]
  ]) columns.add(panel(texture,x1,y1,x2,y2,z));
  const ceiling=new THREE.Group();ceiling.name='Ceiling structure';
  const ring=new THREE.Mesh(new THREE.RingGeometry(476/REFERENCE.width*WIDTH,614/REFERENCE.width*WIDTH,segments),projectedMaterial(texture,{physical:true,roughness:0.4}));
  ring.scale.y=0.27;
  ring.position.set(...fromPixel(876,5,1.4));
  ceiling.add(ring);
  group.add(ceiling,columns);
  return {group,ceiling,columns};
}
