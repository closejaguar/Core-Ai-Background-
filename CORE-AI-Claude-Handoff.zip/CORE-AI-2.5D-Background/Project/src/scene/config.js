// Landmark coordinates are measured against the supplied 1752 × 898 reference.
// Replace only after comparing an actual render with the original image.
export const REFERENCE = { width: 1752, height: 898, url: '/assets/core-ai-reference.jpg' };
export const WIDTH = 20;
export const HEIGHT = WIDTH * REFERENCE.height / REFERENCE.width;
export const MAX_PARALLAX = 0.022;
export function fromPixel(x, y, z = 0) {
  return [(x / REFERENCE.width - 0.5) * WIDTH, (0.5 - y / REFERENCE.height) * HEIGHT, z];
}
