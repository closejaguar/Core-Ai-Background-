export function qualitySettings() {
  const mobile = matchMedia('(max-width: 700px)').matches;
  return { pixelRatio: Math.min(devicePixelRatio || 1, mobile ? 1.5 : 2), segments: mobile ? 64 : 128 };
}
