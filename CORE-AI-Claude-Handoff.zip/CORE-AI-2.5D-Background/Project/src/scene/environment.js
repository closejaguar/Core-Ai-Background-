import * as THREE from 'three';
import { REFERENCE, WIDTH, HEIGHT } from './config.js';
import { createBackground } from './layers.js';
import { createPlatform } from './platform.js';
import { createArchitecture } from './architecture.js';
import { addLighting } from './lighting.js';
import { createCamera, createControls } from './camera.js';
import { qualitySettings } from './performance.js';

export async function mountEnvironment(element, { textureUrl = REFERENCE.url } = {}) {
  const quality = qualitySettings();
  const texture = await new THREE.TextureLoader().loadAsync(textureUrl);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  if (Math.abs(texture.image.width/texture.image.height - REFERENCE.width/REFERENCE.height) > 0.01) {
    texture.dispose();
    throw new Error('The reference aspect ratio must match 1752 × 898. Supply the approved composition without stretching.');
  }
  let renderer;
  try { renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'low-power' }); }
  catch (error) { texture.dispose(); throw error; }
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.NoToneMapping;
  renderer.setPixelRatio(quality.pixelRatio);
  texture.anisotropy = Math.min(4,renderer.capabilities.getMaxAnisotropy());
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x070c14);
  const camera = createCamera();
  scene.add(createBackground(texture));
  const depth = new THREE.Group();
  const platform = createPlatform(texture,quality.segments);
  const architecture = createArchitecture(texture,quality.segments);
  depth.add(platform,architecture.group);
  scene.add(depth);
  addLighting(scene);
  element.append(renderer.domElement);
  const controls = createControls(element,camera);
  let referenceMode = false;
  let frame = 0;
  let lastTime = 0;
  let visible = true;
  let disposed = false;
  function draw(time) {
    frame = 0;
    if (disposed || document.hidden || !visible) return;
    const moving = controls.update(Math.min((time-lastTime)/1000 || 1/60,0.05),referenceMode);
    lastTime = time;
    renderer.render(scene,camera);
    if (moving) requestDraw();
  }
  function requestDraw() { if (!disposed && !frame && !document.hidden && visible) frame=requestAnimationFrame(draw); }
  function resize() {
    const {width,height} = element.getBoundingClientRect();
    if (!width || !height) return;
    renderer.setPixelRatio(qualitySettings().pixelRatio);
    renderer.setSize(width,height,false);
    // Contain framing: retain the entire chamber without distorting portrait embeds.
    const aspect=width/height;
    const h=Math.max(HEIGHT,WIDTH/aspect);
    camera.left=-h*aspect/2; camera.right=h*aspect/2; camera.top=h/2; camera.bottom=-h/2;
    camera.updateProjectionMatrix(); requestDraw();
  }
  const observer = new ResizeObserver(resize);
  observer.observe(element);
  const intersection = new IntersectionObserver(entries => { visible=entries[0].isIntersecting; if (visible) requestDraw(); });
  intersection.observe(element);
  element.addEventListener('pointermove',requestDraw);
  element.addEventListener('pointerleave',requestDraw);
  document.addEventListener('visibilitychange',requestDraw);
  const onContextLost = event => { event.preventDefault(); cancelAnimationFrame(frame); frame=0; element.dispatchEvent(new CustomEvent('environmenterror',{detail:'Graphics context lost. Reload to restore the chamber.'})); };
  renderer.domElement.addEventListener('webglcontextlost',onContextLost);
  resize();
  return {
    get motionEnabled() { return controls.enabled; },
    setMotion(value) { controls.setEnabled(value); requestDraw(); },
    setReference(value) { referenceMode=value; depth.visible=!value; controls.reset(); requestDraw(); },
    setStage(stage) {
      if (!['reference','platform','ceiling','architecture'].includes(stage)) throw new Error('Unknown scene stage');
      referenceMode=stage==='reference'; depth.visible=!referenceMode;
      platform.visible=!referenceMode;
      architecture.ceiling.visible=['ceiling','architecture'].includes(stage);
      architecture.columns.visible=stage==='architecture';
      controls.reset(); requestDraw();
    },
    getViewState() { return { x:camera.position.x, y:camera.position.y, referenceMode }; },
    getMetrics() { return { ...renderer.info.render, geometries:renderer.info.memory.geometries, textures:renderer.info.memory.textures }; },
    dispose() {
      disposed=true; cancelAnimationFrame(frame); observer.disconnect(); intersection.disconnect(); controls.dispose();
      element.removeEventListener('pointermove',requestDraw); element.removeEventListener('pointerleave',requestDraw);
      document.removeEventListener('visibilitychange',requestDraw);
      renderer.domElement.removeEventListener('webglcontextlost',onContextLost);
      scene.traverse(object => { object.geometry?.dispose(); if (object.material) for (const material of [object.material].flat()) material.dispose(); });
      texture.dispose(); renderer.dispose(); renderer.domElement.remove();
    }
  };
}
