import * as THREE from 'three';
import { WIDTH, HEIGHT } from './config.js';
export function createBackground(texture) {
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(WIDTH, HEIGHT), new THREE.MeshBasicMaterial({ map: texture, toneMapped: false }));
  mesh.position.z = -1;
  mesh.name = 'Original reference / skyline / reflections';
  return mesh;
}
