import * as THREE from 'three';
import { WIDTH, HEIGHT } from './config.js';

// Project the original photograph onto shallow geometry from the approved camera.
// At rest every visible fragment samples the same pixel as the reference plane.
// No generated texture or baked fake lighting is introduced.
export function projectedMaterial(texture, { physical = false, roughness = 0.4 } = {}) {
  const material = physical
    ? new THREE.MeshStandardMaterial({ map: texture, metalness: 0.8, roughness, side: THREE.DoubleSide })
    : new THREE.MeshBasicMaterial({ map: texture, side: THREE.DoubleSide });
  material.toneMapped = false;
  material.onBeforeCompile = shader => {
    shader.uniforms.referenceTexture = { value: texture };
    shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nvarying vec2 referenceUV;');
    shader.vertexShader = shader.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      vec4 referencePosition = modelMatrix * vec4(position, 1.0);
      referenceUV = vec2(referencePosition.x / ${WIDTH.toFixed(8)} + 0.5, referencePosition.y / ${HEIGHT.toFixed(8)} + 0.5);`);
    shader.fragmentShader = shader.fragmentShader.replace('#include <common>', '#include <common>\nvarying vec2 referenceUV;\nuniform sampler2D referenceTexture;');
    shader.fragmentShader = shader.fragmentShader.replace('#include <map_fragment>', 'diffuseColor *= texture2D(referenceTexture, referenceUV);');
    // The photograph already contains illumination. Keep its radiance untouched;
    // physical response can be evaluated separately once visual calibration passes.
    if (physical) shader.fragmentShader = shader.fragmentShader.replace('#include <opaque_fragment>', 'outgoingLight = diffuseColor.rgb;\n#include <opaque_fragment>');
  };
  material.customProgramCacheKey = () => `reference-projection-${physical}`;
  return material;
}
