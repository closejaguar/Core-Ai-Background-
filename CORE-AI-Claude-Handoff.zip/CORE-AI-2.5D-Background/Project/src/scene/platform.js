import * as THREE from 'three';
import { fromPixel, WIDTH, REFERENCE } from './config.js';
import { projectedMaterial } from './materials.js';

// Layered circular construction. Projected reference radiance preserves the
// illuminated rings, recessed panels and metallic shading without doubling glow.
export function createPlatform(texture, segments) {
  const group = new THREE.Group();
  group.name = 'Layered circular platform';
  const scale = WIDTH / REFERENCE.width;
  const material = projectedMaterial(texture, { physical: true, roughness: 0.32 });
  const tiers = [
    { name: 'Lower metallic foundation', x: 870, y: 729, radius: 624, ellipse: 160, inner: 0, z: 7.3 },
    { name: 'Outer recessed band', x: 870, y: 716, radius: 580, ellipse: 146, inner: 515, z: 7.5 },
    { name: 'Upper illuminated annulus', x: 870, y: 674, radius: 475, ellipse: 106, inner: 430, z: 7.8 },
    { name: 'Empty metallic center', x: 866, y: 659, radius: 427, ellipse: 83, inner: 0, z: 8.0 }
  ];
  for (const tier of tiers) {
    let geometry;
    if (tier.inner) {
      geometry = new THREE.RingGeometry(tier.inner*scale,tier.radius*scale,segments);
      // RingGeometry is in XY; tilt into the same circular platform plane.
      geometry.rotateX(-Math.PI/2);
    } else {
      geometry = new THREE.CylinderGeometry(tier.radius*scale,tier.radius*scale,0.035,segments,1);
    }
    const mesh = new THREE.Mesh(geometry,material);
    mesh.name = tier.name;
    mesh.rotation.x = Math.asin(tier.ellipse/tier.radius);
    mesh.position.set(...fromPixel(tier.x,tier.y,tier.z));
    group.add(mesh);
  }
  return group;
}
