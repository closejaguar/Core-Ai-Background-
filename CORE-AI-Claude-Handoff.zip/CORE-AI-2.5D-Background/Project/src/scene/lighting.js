import * as THREE from 'three';
export function addLighting(scene) {
  const ambient = new THREE.HemisphereLight(0x90caff, 0x151b30, 0.6);
  const sunset = new THREE.DirectionalLight(0xffaa68, 1.0);
  sunset.position.set(-5, 3, -2);
  scene.add(ambient, sunset);
  // Reference-projected materials preserve baked lighting. Live lights are ready
  // for future unbaked assets; extra bloom would alter the approved photograph.
}
