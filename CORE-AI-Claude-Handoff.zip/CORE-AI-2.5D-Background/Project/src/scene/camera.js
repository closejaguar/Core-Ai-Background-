import * as THREE from 'three';
import { WIDTH, HEIGHT, MAX_PARALLAX } from './config.js';
export function createCamera() {
  const camera = new THREE.OrthographicCamera(-WIDTH/2,WIDTH/2,HEIGHT/2,-HEIGHT/2,0.1,100);
  camera.position.set(0,0,20);
  return camera;
}
export function createControls(element, camera) {
  const target = new THREE.Vector2();
  let enabled = !matchMedia('(prefers-reduced-motion: reduce)').matches;
  const move = event => {
    if (event.pointerType !== 'mouse' || !enabled) return;
    const rect = element.getBoundingClientRect();
    target.set(((event.clientX-rect.left)/rect.width-0.5)*2, (0.5-(event.clientY-rect.top)/rect.height)*2);
  };
  const leave = () => target.set(0,0);
  element.addEventListener('pointermove',move);
  element.addEventListener('pointerleave',leave);
  return {
    get enabled() { return enabled; },
    setEnabled(value) { enabled=value; leave(); },
    update(dt, referenceMode) {
      const x = enabled && !referenceMode ? target.x*MAX_PARALLAX : 0;
      const y = enabled && !referenceMode ? target.y*MAX_PARALLAX : 0;
      const ease = 1-Math.exp(-dt*5);
      camera.position.x += (x-camera.position.x)*ease;
      camera.position.y += (y-camera.position.y)*ease;
      camera.lookAt(0,0,0);
      return Math.abs(camera.position.x-x)+Math.abs(camera.position.y-y)>0.00001;
    },
    reset() { camera.position.set(0,0,20); camera.lookAt(0,0,0); },
    dispose() { element.removeEventListener('pointermove',move); element.removeEventListener('pointerleave',leave); }
  };
}
