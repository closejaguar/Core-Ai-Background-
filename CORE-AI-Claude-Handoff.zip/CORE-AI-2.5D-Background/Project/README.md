# CORE AI command chamber

A modular Three.js 2.5D chamber using the exact user-supplied **1752 × 898 JPG**. The scene preserves the approved static composition and adds real layered platform geometry, shallow structural geometry, and tightly bounded mouse parallax. The center remains empty. No generated artwork or external model generation was used.

## Run

Requires Node.js 20.19+ or 22.12+; validated with Node 24 and npm 11.

```sh
cd /workspace/Core-Ai-Background-
npm ci --cache /workspace/.npm-cache --no-audit --no-fund
npm run check
npm run dev
```

For production, run `npm run build` and serve `dist/` through your website's static host. `npm run preview` serves a local build for validation.

The sole visual asset is `public/assets/core-ai-reference.jpg`, extracted unchanged from the uploaded ZIP. Its original JPEG bytes are retained. Do not overwrite it with generated artwork, change its crop, or stretch its aspect ratio. Cross-origin replacement URLs require CORS permission.

## Validation and previews

```sh
npm test
npm run capture
```

Browser tests use `/usr/bin/chromium`; set `CHROMIUM_PATH` on other systems. Chromium must support WebGL. The test runner uses software WebGL in this environment, so these results do not benchmark device GPUs.

Six browser tests passed: missing-asset handling, desktop/mobile renderer startup and controls, reduced-motion defaults, and real-image visual comparisons at both viewport sizes. The latter compare reference, platform, ceiling and architectural stages, exercise maximum parallax, and verify that comparison mode restores the exact static frame. Console/shader errors are checked. Diagnostic grid tests remain independent of the real-image tests.

`npm run capture` starts and stops its own temporary server, uses the actual JPG, and writes screenshots plus a validation report to `.artifacts/previews/`:

- `desktop.png`, `mobile.png`: complete page previews.
- `desktop-reference.png`, `mobile-reference.png`: comparison views.
- `*-baseline.png`, `*-platform.png`, `*-ceiling.png`, `*-architecture.png`: isolated scene progression.
- `validation.json`: mean RGB differences and rendering counters.

Baseline-versus-final mean per-channel error was **0.050/255 desktop** and **0.089/255 mobile**, with no pixels exceeding the test's large-difference threshold. This measures preservation of the rendered photograph, not accuracy of recovered hidden geometry. Desktop and mobile captures were visually inspected.

## Architecture

- `environment.js`: asynchronous mount, texture loading, color management, renderer, framing, visibility and disposal.
- `layers.js`: original full-frame texture, preserving the sunset, skyline, furniture, floor and reflections.
- `platform.js`: lower cylinder, recessed annulus, illuminated annulus and empty central disk. Tilted circular geometry is aligned to the reference's projected ellipses.
- `architecture.js`: six shallow column panels and a ceiling annulus.
- `materials.js`: reference texture projected from the original camera onto visible geometry. MeshStandardMaterial stores metallic roughness settings; its photographed radiance is preserved rather than relit.
- `lighting.js`: lights available for future unbaked assets. They do not alter current reference-projected surfaces.
- `camera.js`: orthographic approved baseline, eased mouse-only movement, no unrestricted orbit.
- `performance.js`: device-dependent segment and pixel-ratio caps.

Opaque geometry covers the corresponding image region through the depth buffer. At the approved camera angle, its projected texture samples match the underlying image, avoiding duplicate rings and columns. No hidden scenery is invented or inpainted. Parallax is intentionally limited to 0.022 world units, typically around a pixel of foreground displacement; small edge disocclusions remain possible during movement. Larger camera moves are unsupported.

The platform outer footprint is aligned near (870,729), with radii 624px × 160px. The upper illuminated annulus uses approximately (870,674), 475px × 106px. The ceiling ring is centered around (876,5). These are image landmark approximations; single-image reconstruction does not determine actual room dimensions.

## Integrate into an existing website

Import the isolated module into your existing bundler:

```js
import { mountEnvironment } from './scene/environment.js';

const chamber = await mountEnvironment(container, {
  textureUrl: '/assets/core-ai-reference.jpg'
});

// Optional controls:
chamber.setMotion(false);
chamber.setReference(true);
chamber.setStage('architecture'); // reference | platform | ceiling | architecture

// On component unmount:
chamber.dispose();
```

Copy `src/scene/` and the reference asset into your website. Install the pinned Three.js version from `package.json`. Give the container a defined size; prefer `width: 100%; aspect-ratio: 1752 / 898`. Catch mount errors and supply your loading/error UI, following `src/main.js`. The demo's header/footer are independent of the scene and need not be integrated. No other website components were modified because the repository initially had no website source.

The camera uses contain framing for differently shaped embeds. The mobile demo keeps the complete chamber in a wide panel within the portrait page. This deliberately avoids distorting the room or inventing portrait artwork. A fullscreen portrait treatment would require substantial cropping or approved additional artwork.

## Performance and remaining differences

- Production JavaScript: approximately 124 KB gzip; source JPG: approximately 1 MB.
- One texture, 12 draw calls; approximately 1,866 desktop / 970 mobile triangles.
- DPR capped at 2 desktop / 1.5 narrow screens; 128/64 radial segments.
- Rendering occurs on demand, continues only while easing, and pauses offscreen or in hidden tabs.
- No costly dynamic reflection targets, shadow maps or postprocessing passes.

Blue illumination, bloom, floor reflections, recessed detailing and shadows remain photographed. They do not respond independently to live lighting or new objects. This preserves fidelity but is not a fully relit PBR reconstruction. No separate bloom pass is applied because the image already contains glow. Furniture, vegetation, complex window structure and distant city remain image-based. Only selected columns and the ceiling annulus have depth. The texture may reveal small sampling differences on geometry, particularly after mobile downsampling. Device performance, touchscreen camera interaction, arbitrary viewpoints and full website integration have not been validated; pointer parallax deliberately applies only to a mouse.

The delivered result is a working, bounded 2.5D scene. It is not a complete 3D room and does not support adding arbitrary foreground objects with accurate dynamic reflections.
