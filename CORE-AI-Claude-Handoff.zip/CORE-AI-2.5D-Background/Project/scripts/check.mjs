import { access } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { readdir } from 'node:fs/promises';
async function check(dir) {
  for (const entry of await readdir(dir,{withFileTypes:true})) {
    const path=`${dir}/${entry.name}`;
    if (entry.isDirectory()) await check(path);
    else if (path.endsWith('.js')) execFileSync(process.execPath,['--check',path],{stdio:'inherit'});
  }
}
await check('src');
try { await access('public/assets/core-ai-reference.jpg'); }
catch { console.error('Required asset missing: public/assets/core-ai-reference.jpg. Visual validation is blocked.'); process.exitCode=1; }
