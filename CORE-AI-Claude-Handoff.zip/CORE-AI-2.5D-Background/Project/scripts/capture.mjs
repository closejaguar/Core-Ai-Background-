import { access, mkdir, writeFile } from 'node:fs/promises';
import { spawn } from 'node:child_process';
import { chromium } from '@playwright/test';
import { PNG } from 'pngjs';
await access('public/assets/core-ai-reference.jpg');
await mkdir('.artifacts/previews',{recursive:true});
const server=spawn(process.execPath,['node_modules/vite/bin/vite.js','--host','127.0.0.1','--port','5174','--strictPort'],{stdio:'ignore'});
let browser;
const report={};
try {
  let ready=false;
  for(let i=0;i<50;i++) {
    try { const response=await fetch('http://127.0.0.1:5174'); if(response.ok){ready=true;break;} } catch {}
    await new Promise(resolve=>setTimeout(resolve,100));
  }
  if(!ready) throw new Error('Preview server did not start.');
  browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  for(const [name,viewport] of [['desktop',{width:1440,height:900}],['mobile',{width:390,height:844}]]) {
    const page=await browser.newPage({viewport,reducedMotion:'reduce'});
    const errors=[];
    page.on('pageerror',error=>errors.push(error.message));
    await page.goto('http://127.0.0.1:5174');
    await page.waitForFunction(()=>window.chamber?.getMetrics().calls>0);
    if(errors.length) throw new Error(errors.join('\n'));
    await page.screenshot({path:`.artifacts/previews/${name}.png`,fullPage:true});
    await page.locator('#reference').click();
    await page.waitForFunction(()=>window.chamber.getMetrics().calls===1);
    await page.screenshot({path:`.artifacts/previews/${name}-reference.png`,fullPage:true});
    const baseline=PNG.sync.read(await page.locator('canvas').screenshot({path:`.artifacts/previews/${name}-baseline.png`}));
    report[name]={viewport,stages:{}};
    for (const stage of ['platform','ceiling','architecture']) {
      await page.evaluate(stage=>window.chamber.setStage(stage),stage);
      await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
      const actual=PNG.sync.read(await page.locator('canvas').screenshot({path:`.artifacts/previews/${name}-${stage}.png`}));
      let sum=0,large=0;
      for(let i=0;i<actual.data.length;i+=4) {
        let diff=0;for(let c=0;c<3;c++) diff+=Math.abs(actual.data[i+c]-baseline.data[i+c]);
        sum+=diff;if(diff>60) large++;
      }
      report[name].stages[stage]={meanChannelError:sum/(actual.width*actual.height*3),fractionLargeDifferences:large/(actual.width*actual.height),render:await page.evaluate(()=>window.chamber.getMetrics())};
    }
    await page.close();
  }
  await writeFile('.artifacts/previews/validation.json',JSON.stringify(report,null,2)+'\n');
} finally { await browser?.close(); server.kill('SIGTERM'); }
