# CORE AI — 2.5D Futuristic Environment Development Project

## PROJECT OVERVIEW

We are developing a premium, futuristic 2.5D environment for the CORE AI Solutions website using Three.js.

I have attached the exact reference image of the environment we want.

**IMPORTANT: This is not an image-generation project. This is a web development and 2.5D environment reconstruction project.**

The reference image is the approved design. Our goal is to reproduce its appearance as faithfully as possible while introducing convincing depth, subtle camera movement, realistic lighting, and optimized performance.

Do not redesign the room or generate a different environment.

## PHASE 1 — ANALYZE THE REFERENCE IMAGE

Carefully examine the attached image.

Identify the following architectural features:

1. The massive circular futuristic command chamber.
2. The panoramic curved glass windows.
3. The orange, pink, and purple sunset skyline.
4. The dark metallic circular platform centered in the foreground.
5. The concentric electric-blue illuminated rings embedded in the platform.
6. The large circular illuminated ceiling structure.
7. The dark metallic structural columns.
8. The glossy reflective flooring.
9. The futuristic lounge furniture positioned around the outer edges.
10. The overall cinematic perspective and lighting.

Analyze the composition, perspective, approximate dimensions, and relative positioning of each element.

The reference image must remain the primary visual authority.

## PHASE 2 — DETERMINE THE BEST 2.5D ARCHITECTURE

Develop a hybrid 2.5D environment using Three.js.

Use a combination of:

- High-resolution image textures.
- Layered image planes.
- Simplified 3D architectural geometry.
- Real 3D foreground objects.
- Depth-based parallax.
- Physically based materials.
- Realistic lighting and subtle bloom.

Do not attempt to procedurally reconstruct every visual detail.

The original reference image should preserve complex visual information that would be difficult to recreate accurately.

### Background layer

Preserve the original sunset skyline, distant buildings, sky, and atmospheric lighting.

Use the original image or accurately extracted portions of it as textures.

Do not generate a different skyline.

### Middle architectural layer

Reconstruct the major architectural elements using simplified Three.js geometry where practical.

These include:

- Curved window frames.
- Dark metallic columns.
- Selected wall structures.
- Ceiling rings.
- Architectural lighting elements.

All geometry must match the perspective and proportions of the reference image.

### Foreground layer

Create a convincing 3D circular platform matching the original image.

Include:

- Layered metallic construction.
- Concentric illuminated blue rings.
- Recessed panel detailing.
- Metallic surface roughness.
- Realistic shadows.
- Subtle reflections.
- Physically plausible illumination.

The center of the platform must remain empty.

## PHASE 3 — PRESERVE VISUAL ACCURACY

This is the most important phase.

Before introducing any 3D geometry, display the original reference image inside the Three.js environment.

Ensure the original composition is reproduced correctly.

Then progressively introduce depth and geometry without destroying the original appearance.

Use the following development sequence:

1. Display the original image accurately.
2. Match the camera framing and aspect ratio.
3. Establish a basic depth-layer system.
4. Introduce the circular platform.
5. Introduce the ceiling geometry.
6. Add structural window elements.
7. Implement lighting and reflections.
8. Add subtle parallax movement.
9. Optimize desktop and mobile rendering.
10. Compare the final result with the original image.

After each major step, visually compare the result against the reference.

Avoid duplicate architectural elements or obvious misalignment between image textures and 3D geometry.

Where geometry replaces an image element, properly mask, remove, or cover the original element to avoid double-rendering.

If an element cannot be reconstructed accurately, preserve its original appearance rather than replacing it with inferior geometry.

## PHASE 4 — CAMERA AND INTERACTION

The environment should initially use a cinematic, front-facing camera matching the original reference image.

Implement subtle movement to create the illusion of depth.

Potential interactions include:

- Gentle mouse-driven parallax.
- Smooth camera easing.
- Minimal depth shifts between architectural layers.
- Subtle environmental animation.

Do not implement unrestricted 360-degree camera rotation.

The goal is to preserve the reference composition while making the environment feel alive.

Avoid excessive camera movement that exposes missing geometry, texture seams, or incomplete architecture.

## PHASE 5 — VISUAL QUALITY

The environment should look like a premium cinematic science-fiction interior.

Use:

- Physically based metallic materials.
- Electric-blue emissive lighting.
- Controlled bloom.
- Appropriate tone mapping.
- Smooth shadows.
- Realistic surface reflections where feasible.
- High-quality texture filtering.
- Correct color management.

Avoid excessive glow, cartoon-like materials, low-resolution textures, and generic procedural architecture.

The final environment should retain the original contrast between the cool blue interior lighting and the warm sunset outside.

## PHASE 6 — WEBSITE PERFORMANCE

The finished environment must be suitable for a production website.

Optimize for:

- Desktop browsers.
- Mobile devices.
- Responsive screen sizes.
- Efficient GPU rendering.
- Reduced unnecessary geometry.
- Compressed textures where appropriate.
- Efficient animation loops.
- Reasonable loading times.

Create a desktop layout and a mobile-compatible layout.

Do not simply stretch or distort the desktop image to fit a phone screen.

Preserve the architectural composition using responsive camera framing and appropriate image cropping.

If additional mobile-specific artwork is required, identify that requirement rather than inventing new architectural details.

## PHASE 7 — OPTIONAL TRIPO AI ASSETS

We may use Tripo AI to generate individual 3D assets.

Potential assets include:

- The central circular platform.
- Selected futuristic architectural components.
- Decorative mechanical structures.

However, Tripo AI should only be used when the generated asset would improve visual accuracy or reduce development time.

Do not automatically assume the entire environment should be generated as a single 3D model.

If you recommend Tripo AI for a component, provide:

1. The exact component to generate.
2. A short optimized text prompt.
3. The recommended reference-image crop.
4. The desired output format, preferably GLB.
5. How the asset will be integrated into Three.js.

Do not initiate external asset generation without approval.

## PHASE 8 — CODE STRUCTURE

Use the existing website's technology stack wherever possible.

If Three.js is already installed, reuse the existing setup.

Prefer a modular implementation with separate components or modules for:

- Environment setup.
- Background image layers.
- Architectural geometry.
- Platform geometry.
- Lighting.
- Camera controls.
- Performance optimization.

Avoid unnecessary dependencies.

Keep the environment isolated so it can be modified, disabled, or replaced without affecting unrelated website functionality.

Do not modify unrelated project files.

## PHASE 9 — VALIDATION AND DELIVERABLES

Provide:

1. A working 2.5D environment implementation.
2. The source code.
3. A clear explanation of the scene architecture.
4. Instructions for integrating the environment into the website.
5. A list of any required textures or assets.
6. Desktop and mobile preview screenshots.
7. Performance considerations.
8. A list of remaining visual differences from the reference.

The completed environment must closely resemble the original image from the approved camera angle.

## STRICT EXCLUSIONS

Do not add:

- Characters.
- Humanoid figures.
- Statues.
- Holographic people.
- Vehicles.
- Spaceships.
- Floating central decorations.
- Unrequested architectural features.
- Additional platforms.

Keep the center of the room empty.

## IMPORTANT DEVELOPMENT INSTRUCTIONS

Before modifying any files:

1. Inspect the existing project and the supplied reference image.
2. Explain your proposed technical architecture.
3. Identify what will remain image-based and what will become 3D geometry.
4. Explain how you will preserve the original visual appearance.
5. Identify any limitations or additional assets needed.
6. Present a step-by-step implementation plan.

**STOP AND WAIT FOR MY APPROVAL BEFORE IMPLEMENTING THE PLAN.**

Do not claim that a flat image has been converted into true 3D geometry.

Do not generate replacement artwork without permission.

Do not alter unrelated website components.

## FINAL OBJECTIVE

Create a visually stunning, responsive, realistic 2.5D futuristic CORE AI command chamber that looks almost identical to the supplied reference image, with convincing architectural depth and subtle interactive movement.

Visual fidelity is more important than unnecessary geometric complexity.

**The approved reference image is the design. Your job is to bring that exact design to life on the web.**